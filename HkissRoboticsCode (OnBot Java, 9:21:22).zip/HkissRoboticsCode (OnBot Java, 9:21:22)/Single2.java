package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

@TeleOp

public class Single2 extends LinearOpMode{
    DcMotor lift;
    
    @Override
    public void runOpMode()
    {
        lift = hardwareMap.get(DcMotor.class, "lift");
        lift.setTargetPosition(lift.getCurrentPosition());
        lift.setPower(0.5);
        lift.setMode(DcMotor.RunMode.RUN_TO_POSITION);
        lift.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        long switchTime1 = 0;
        
        int liftPosition = lift.getCurrentPosition();
        
        waitForStart();
        while(opModeIsActive()) {
            if (gamepad1.x && Arepikov_Mechanum_Teleop.getTime() - switchTime1 > 1000) {
                liftPosition += 500;
                switchTime1 = Arepikov_Mechanum_Teleop.getTime();
            } else if (gamepad1.y && Arepikov_Mechanum_Teleop.getTime() - switchTime1 > 1000) {
                liftPosition -= 500;
                switchTime1 = Arepikov_Mechanum_Teleop.getTime();
            }
            
            if (gamepad1.dpad_up) {
                liftPosition += 1;
            } else if (gamepad1.dpad_down) {
                liftPosition -= 1;
            }
            
            lift.setTargetPosition(liftPosition);
            
            telemetry.addData("Position", lift.getCurrentPosition());
            telemetry.addData("Goal", lift.getTargetPosition());
            telemetry.update();
        }
    }
}