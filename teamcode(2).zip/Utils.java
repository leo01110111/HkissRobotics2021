package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import org.firstinspires.ftc.robotcore.external.android.AndroidTextToSpeech;

@Disabled

public class Utils {
    
    // public static void speak()
    // {
    //     new AndroidTextToSpeech().initialize();
    //     new AndroidTextToSpeech().speak("Hello!");
    // }
    
    // void tests()
    // {
    //     AndroidTextToSpeech.initialize();
    //     AndroidTextToSpeech.speak("hello");
    // }
    // todo: write your code here
}
