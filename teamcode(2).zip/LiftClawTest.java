package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

@TeleOp

public class LiftClawTest extends LinearOpMode{
    DcMotor lift;
    Servo flipper;
    Servo claw;
    
    @Override
    public void runOpMode()
    {
        lift = hardwareMap.get(DcMotor.class, "lift");
        lift.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        lift.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        flipper = hardwareMap.get(Servo.class, "flipper");
        claw = hardwareMap.get(Servo.class, "claw");
        //double pos = claw.getPosition();
        waitForStart();
        
        while (opModeIsActive()) {
            lift.setPower(gamepad1.right_stick_y);
            claw.setPosition((gamepad1.left_stick_x/2)+0.5);
            flipper.setPosition((gamepad2.left_stick_x/2)+0.5);
            /* tried using right trigger buttons to control the claw. I need help! 
            if( gamepad1.right_trigger == 1){
                pos+=0.01;
            }
            else if( gamepad1.right_bumper == true){
                pos-=0.01;
            }
            else{
                pos = claw.getPosition();
            }
            claw.setPosition(pos);*/
            
        }

    }
}