/*
Copyright 2020 

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and
associated documentation files (the "Software"), to deal in the Software without restriction,
including without limitation the rights to use, copy, modify, merge, publish, distribute,
sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
package org.firstinspires.ftc.teamcode;


import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.Blinker;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.Position;
import org.firstinspires.ftc.robotcore.external.navigation.Velocity;

import com.qualcomm.robotcore.util.ElapsedTime;

import java.util.Arrays;

/**
 * Remove a @Disabled the on the next line or two (if present) to add this opmode to the Driver Station OpMode list,
 * or add a @Disabled annotation to prevent this OpMode from being added to the Driver Station
 */
@TeleOp
@Disabled

public class Mechanum1 extends LinearOpMode 
{
    Blinker         control_Hub;
    DcMotor         leftBack, rightBack, rightFrontal, leftFrontal;
    BNO055IMU       imu;
    Orientation     lastAngles = new Orientation();
    //No clue, cumulative, -180 to 180
    double          globalAngle, angle, actualAngle;
    double          power=.30;
    double          offset=0;
    double          bumperOffset;
    int             loopCount1;
    long            headlessWait;
    double          v1, v2, v3, v4; 
    double          r, robotAngle, rightX;
    
    boolean         headless=false;
    
    //time given in milliseconds
    long start = System.nanoTime();
    long time;
    
    //int[] arr = { 10, 20, 30 };


    @Override
    public void runOpMode() {
        
        
        //set up motor stuff
        //Give motors names
        leftBack = hardwareMap.get(DcMotor.class, "leftBack");
        rightFrontal = hardwareMap.get(DcMotor.class, "rightFront");
        leftFrontal = hardwareMap.get(DcMotor.class, "leftFront");
        rightBack = hardwareMap.get(DcMotor.class, "rightBack");
        
        //set motors to speed mode
        leftBack.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightFrontal.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        leftFrontal.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        rightBack.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
        
        //set motors to stop at 0 power instead of coasting
        leftBack.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rightBack.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        leftFrontal.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rightFrontal.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        
        //set two motors to go backwards, so that we can just tell the motors
        //to do what we want, instead of worryign about direction.
        //Don't worry about this when writing code
        leftFrontal.setDirection(DcMotor.Direction.REVERSE);
        rightFrontal.setDirection(DcMotor.Direction.REVERSE);
        
        
        //set up gyroscope stuff
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        
        parameters.mode             = BNO055IMU.SensorMode.IMU;
        parameters.angleUnit        = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit        = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.loggingEnabled   = false;

        imu = hardwareMap.get(BNO055IMU.class, "imu");

        imu.initialize(parameters);
        
        //Send telemetry to robot
        telemetry.addData("Calibration", imu.getCalibrationStatus().toString());
        telemetry.addData("Status", "Initialized");
        telemetry.update();
    
        // Wait for the game to start (driver presses PLAY)
        waitForStart();
        // run until the end of the match (driver presses STOP)
        while (opModeIsActive()) {
            opModeIsActive();
            
            //get the various angles
            getAngle();
            
            //set motor powers and stuff
            generalPower();
            
            time = getTime();
            
            //return to start angle
            if (gamepad1.b == true) 
            {
                returnToForward();
            }//set start angle
            else if (gamepad1.y == true) 
            {
                offset();
            } //headless mode
            else if (gamepad1.x == true)
            {
                //so that it doesn't switch every update
                if ((getTime()) - headlessWait >= 1000)
                {
                    headless = switchInput(headless);
                    headlessWait = getTime();
                }
            }
            
            //telemtry loop
            if (loopCount1 % 100 == 0) {
                telemetry.addData("Status", "Running");
                telemetry.addData("Calibration", imu.getCalibrationStatus().toString());
                telemetry.addData("angle", angle);
                telemetry.addData("Actual Angle", actualAngle);
                telemetry.addData("joyLX", gamepad1.left_stick_x);
                telemetry.addData("robotAngle", robotAngle);
                telemetry.addData("Left Front", v1);
                telemetry.addData("Right Front", v2);
                telemetry.addData("Left Back", v3);
                telemetry.addData("Right Front", v4);
                telemetry.addData("Headless Mode Active?", headless);
                telemetry.addData("time", time);
                telemetry.update();
                loopCount1 = 0;
            }
            
            setPower();
            
            //preventing integer overflow (some magic number, less than int overflow)
            //currently 100,000,000 <- please update if changed
            if (loopCount1 == 100000000)
            {
                loopCount1 = 0;
            }
            ++loopCount1;
        }
        
    }
    
    /* things to add
    Return to Start
    Tune braking system curve?      NAH
    Heading control mode            DONE
    Gyro assisted strafing
    */
    
    private double getGlobalAngle()
    {
            Orientation angles = imu.getAngularOrientation(
                AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
            
            double deltaAngle = angles.firstAngle - lastAngles.firstAngle;
            
            if (deltaAngle < -180)
                deltaAngle += 360;
            else if (deltaAngle > 180)
                deltaAngle -= 360;
                
            globalAngle += deltaAngle;
            lastAngles = angles;
            
            return globalAngle;
    }
    
    private void setPower()
    {
        bumperOffset = (1-gamepad1.right_trigger)+0.1;
        leftFrontal.setPower(v1*bumperOffset);
        rightFrontal.setPower(v2*bumperOffset);
        leftBack.setPower(v3*bumperOffset);
        rightBack.setPower(v4*bumperOffset);
    }
    
    //time in milliseconds. NOT NANOSECONDS
    private long getTime()
    {
        return (System.nanoTime() - start) / 1000000;
    }
    
    private void generalPower()
    {
            r = Math.hypot(gamepad1.left_stick_x, gamepad1.left_stick_y);
            robotAngle = Math.atan2(gamepad1.left_stick_y, gamepad1.left_stick_x) + Math.PI/4;
            rightX = gamepad1.right_stick_x;
            
            if (headless)
            {
                robotAngle += actualAngle*(Math.PI/180);
            }
            
            v1 = r * Math.cos(robotAngle) + rightX;
            v2 = r * Math.sin(robotAngle) + rightX;
            v3 = r * Math.sin(robotAngle) - rightX;
            v4 = r * Math.cos(robotAngle) - rightX;
    }
    
    private void getAngle()
    {
            Orientation angles = imu.getAngularOrientation(
            AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
            
            angle = getGlobalAngle();
            actualAngle = angles.firstAngle + offset;
            
            //correct for offset going out of [-180,180]
            //if (actualAngle >= 180) {
            //    actualAngle = -180 + (actualAngle - 180);
            //} else if (actualAngle <= 180) {
            //    actualAngle = 180 + (actualAngle + 180);
            //}
    }
    
    private void offset()
    {
        Orientation angles = imu.getAngularOrientation(
            AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        
        offset = -angles.firstAngle;
    }
    
    public boolean switchInput(boolean input)
    {
        if (input == true){
            return false;
        } else {
            return true;
        }
    }
    
    private void returnToForward()
    {
        while (Math.abs(actualAngle) >= 10)
        {
            opModeIsActive();
            if (actualAngle <= 0)
            {
                v1 = -1;
                v2 = -1;
                v3 = 1;
                v4 = 1;
                telemetry.addLine("if1");
            } else if (actualAngle >= 0) {
                v1 = 1;
                v2 = 1;
                v3 = -1;
                v4 = -1;
                telemetry.addLine("if2");
            }
            
            setPower();
            getAngle();
            telemetry.addLine("Homing...");
            telemetry.addData("Actual Angle", actualAngle);
            telemetry.update();
        }
    }
    
    
    
}
