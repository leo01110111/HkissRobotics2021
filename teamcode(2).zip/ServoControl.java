package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp

public class ServoControl extends LinearOpMode{
    private Servo server;
    
    private void servo(double fraction)
    {
        server.setPosition(fraction);
        
    }
    
    @Override
    public void runOpMode() {
        
        server = hardwareMap.get(Servo.class, "servo");
        
        telemetry.addLine("Ready!");
        telemetry.addData("port", server.getPortNumber());
        telemetry.update();
        
        waitForStart();
        
        while(opModeIsActive())
        {
            servo((gamepad1.left_stick_x/2)+0.5);
            telemetry.addData("Left X", (gamepad1.left_stick_x/2)+0.5);
            telemetry.addData("servo Pos", server.getPosition());
            telemetry.update();
        }
    }
}