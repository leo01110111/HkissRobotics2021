/*
 * Copyright (c) 2019 OpenFTC Team
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import org.firstinspires.ftc.robotcore.external.hardware.camera.WebcamName;
import org.opencv.core.Mat;
import org.opencv.core.Point;
import org.opencv.core.Scalar;
import org.opencv.core.Size;
import org.opencv.core.MatOfPoint;
import org.opencv.core.Core;
import org.opencv.imgproc.Moments;
import org.opencv.imgproc.Imgproc;
import org.openftc.easyopencv.OpenCvCamera;
import org.openftc.easyopencv.OpenCvCameraFactory;
import org.openftc.easyopencv.OpenCvCameraRotation;
import org.openftc.easyopencv.OpenCvPipeline;
import org.openftc.easyopencv.OpenCvWebcam;

import java.util.List;
import java.util.ArrayList;


@TeleOp
public class WebcamExample extends LinearOpMode
{
    OpenCvWebcam webcam;
    
    static int x = 0;
    static int y = 0;
    
    static int hLow = 0;
    static int sLow = 0;
    static int vLow = 0;
    
    static int hHigh = 255;
    static int sHigh = 255;
    static int vHigh = 255;
    
    int currSwitch = 0;

    @Override
    public void runOpMode()
    {
        int cameraMonitorViewId = hardwareMap.appContext.getResources().getIdentifier("cameraMonitorViewId", "id", hardwareMap.appContext.getPackageName());
        webcam = OpenCvCameraFactory.getInstance().createWebcam(hardwareMap.get(WebcamName.class, "Webcam 1"), cameraMonitorViewId);

        webcam.setPipeline(new colorPipeTest());

        webcam.setMillisecondsPermissionTimeout(2500); // Timeout for obtaining permission is configurable. Set before opening.
        webcam.openCameraDeviceAsync(new OpenCvCamera.AsyncCameraOpenListener()
        {
            @Override
            public void onOpened()
            {
                webcam.startStreaming(320, 240, OpenCvCameraRotation.UPRIGHT);
            }

            @Override
            public void onError(int errorCode)
            {
                /*
                 * This will be called if the camera could not be opened
                 */
            }
        });

        telemetry.addLine("Waiting for start");
        telemetry.update();

        waitForStart();

        while (opModeIsActive())
        {
            telemetry.addData("Current X", x);
            telemetry.addData("hlow", hLow);
            telemetry.addData("hHigh", hHigh);
            telemetry.addData("sLow", sLow);
            telemetry.addData("sHigh", sHigh);
            telemetry.addData("vLow", vLow);
            telemetry.addData("vHigh", vHigh);
            telemetry.update();


            if(gamepad1.a)
            {
                webcam.stopStreaming();
            }
            
            if(gamepad1.left_bumper) {
                currSwitch += 1;
            }
            
            if (currSwitch % 3 == 0) {
                hLow -= (int)(gamepad1.left_stick_y * 3);
                hHigh -= (int)(gamepad1.right_stick_y * 3);
            } else if (currSwitch % 3 == 1) {
                sLow -= (int)(gamepad1.left_stick_y * 3);
                sHigh -= (int)(gamepad1.right_stick_y * 3);
            } if (currSwitch % 3 == 2) {
                vLow -= (int)(gamepad1.left_stick_y * 3);
                vHigh -= (int)(gamepad1.right_stick_y * 3);
            }
            
            sleep(100);
        }
    }

    class colorPipeTest extends OpenCvPipeline
    {
        Mat blurredImage = new Mat();
        Mat hsvImage = new Mat();
        
        Mat thresh = new Mat();
        
        Mat output = new Mat();
        
        Mat dilated = new Mat();
        Mat hierarchey = new Mat();
        List<MatOfPoint> contours = new ArrayList<>();
        
        @Override
        public Mat processFrame(Mat input)
        {
            int hLow = WebcamExample.hLow;
            int sLow = WebcamExample.sLow;
            int vLiw = WebcamExample.vLow;
            int hHigh = WebcamExample.hHigh;
            int sHigh = WebcamExample.sHigh;
            int vHigh = WebcamExample.vHigh;
            contours.clear();
            
            output = input;
            
            Imgproc.blur(input, blurredImage, new Size(3, 3));
            Imgproc.cvtColor(blurredImage, hsvImage, Imgproc.COLOR_BGR2HSV);
            
            Core.inRange(hsvImage, new Scalar(WebcamExample.hLow, WebcamExample.sLow, WebcamExample.vLow),
                new Scalar(WebcamExample.hHigh, WebcamExample.sHigh, WebcamExample.vHigh), thresh);    
            
            //return colorRange;
            
            //dilate the image, to make it better for the next step
            Mat kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, new Size(5, 5));
            Imgproc.dilate(thresh, dilated, kernel);
            
            //find the contours
            Imgproc.findContours(dilated, contours, hierarchey, Imgproc.RETR_TREE, Imgproc.CHAIN_APPROX_SIMPLE);

            Imgproc.drawContours(input, contours, -1, new Scalar(0,255,0), 1);
            
            double maxVal = 0;
            int maxValIdx = 0;
            if (!contours.isEmpty()) {
                for (int contourIdx = 0; contourIdx < contours.size(); contourIdx++)
                {
                    double contourArea = Imgproc.contourArea(contours.get(contourIdx));
                    if (maxVal < contourArea)
                    {
                        maxVal = contourArea;
                        maxValIdx = contourIdx;
                    }
                }
            } 
            
            //make sure the contour is big enough. if not, put some text on screen and return.
            if (maxVal < 100) 
            {
                Imgproc.putText(output, "no target", new Point(10, 20), 0, 1, new Scalar(0, 0, 255));
                return output;
            }
            
            Imgproc.drawContours(input, contours, maxValIdx, new Scalar(255,0,0), 2);
            
            Moments mu = Imgproc.moments(contours.get(maxValIdx));
            WebcamExample.x = (int) (mu.get_m10() / mu.get_m00());
            WebcamExample.y = (int) (mu.get_m01() / mu.get_m00());
            
            //draw a circle at the center of the contour, write where it is, and exit
            Imgproc.circle(output, new Point(x, y), 3, new Scalar(0,255,255));
            Imgproc.putText(output, "target at x = " + WebcamExample.x, new Point(10, 20), 1, 1, new Scalar(0, 0, 0));
            
            
            return output;
            
        }
    }

    /*
     * An example image processing pipeline to be run upon receipt of each frame from the camera.
     * Note that the processFrame() method is called serially from the frame worker thread -
     * that is, a new camera frame will not come in while you're still processing a previous one.
     * In other words, the processFrame() method will never be called multiple times simultaneously.
     *
     * However, the rendering of your processed image to the viewport is done in parallel to the
     * frame worker thread. That is, the amount of time it takes to render the image to the
     * viewport does NOT impact the amount of frames per second that your pipeline can process.
     *
     * IMPORTANT NOTE: this pipeline is NOT invoked on your OpMode thread. It is invoked on the
     * frame worker thread. This should not be a problem in the vast majority of cases. However,
     * if you're doing something weird where you do need it synchronized with your OpMode thread,
     * then you will need to account for that accordingly.
     */
    class SamplePipeline extends OpenCvPipeline
    {
        boolean viewportPaused;

        /*
         * NOTE: if you wish to use additional Mat objects in your processing pipeline, it is
         * highly recommended to declare them here as instance variables and re-use them for
         * each invocation of processFrame(), rather than declaring them as new local variables
         * each time through processFrame(). This removes the danger of causing a memory leak
         * by forgetting to call mat.release(), and it also reduces memory pressure by not
         * constantly allocating and freeing large chunks of memory.
         */

        @Override
        public Mat processFrame(Mat input)
        {
            /*
             * IMPORTANT NOTE: the input Mat that is passed in as a parameter to this method
             * will only dereference to the same image for the duration of this particular
             * invocation of this method. That is, if for some reason you'd like to save a copy
             * of this particular frame for later use, you will need to either clone it or copy
             * it to another Mat.
             */

            /*
             * Draw a simple box around the middle 1/2 of the entire frame
             */
            Imgproc.rectangle(
                    input,
                    new Point(
                            input.cols()/4,
                            input.rows()/4),
                    new Point(
                            input.cols()*(3f/4f),
                            input.rows()*(3f/4f)),
                    new Scalar(0, 255, 0), 4);

            /**
             * NOTE: to see how to get data from your pipeline to your OpMode as well as how
             * to change which stage of the pipeline is rendered to the viewport when it is
             * tapped, please see {@link PipelineStageSwitchingExample}
             */

            return input;
        }

        @Override
        public void onViewportTapped()
        {
            /*
             * The viewport (if one was specified in the constructor) can also be dynamically "paused"
             * and "resumed". The primary use case of this is to reduce CPU, memory, and power load
             * when you need your vision pipeline running, but do not require a live preview on the
             * robot controller screen. For instance, this could be useful if you wish to see the live
             * camera preview as you are initializing your robot, but you no longer require the live
             * preview after you have finished your initialization process; pausing the viewport does
             * not stop running your pipeline.
             *
             * Here we demonstrate dynamically pausing/resuming the viewport when the user taps it
             */

            viewportPaused = !viewportPaused;

            if(viewportPaused)
            {
                webcam.pauseViewport();
            }
            else
            {
                webcam.resumeViewport();
            }
        }
    }
}