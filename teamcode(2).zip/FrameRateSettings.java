package org.firstinspires.ftc.teamcode;


public class FrameRateSettings {

    // todo: write your code here
}