package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.Blinker;
import com.qualcomm.robotcore.hardware.Gyroscope;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.hardware.bosch.BNO055IMU;
import org.firstinspires.ftc.robotcore.external.navigation.Orientation;
import org.firstinspires.ftc.robotcore.external.navigation.AxesReference;
import org.firstinspires.ftc.robotcore.external.navigation.AxesOrder;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;

@TeleOp
@Disabled

public class MechanumAngleTest extends LinearOpMode{
    private Blinker blinkLight;
    private Blinker expansion_Hub_2;
    private BNO055IMU eimu, cimu;
    private DcMotor intake, leftBack, leftFront, rightBack, rightFront, lift;
    
    double [] motor = new double [6];
    
    private void gyroSetup()
    {
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        parameters.mode             = BNO055IMU.SensorMode.IMU;
        parameters.angleUnit        = BNO055IMU.AngleUnit.DEGREES;
        parameters.accelUnit        = BNO055IMU.AccelUnit.METERS_PERSEC_PERSEC;
        parameters.loggingEnabled   = false;
    
        //set up the IMU (kinda)
        cimu = hardwareMap.get(BNO055IMU.class, "imu");
        eimu = hardwareMap.get(BNO055IMU.class, "imu2");
    
        //actually set up the IMU
        cimu.initialize(parameters);
        eimu.initialize(parameters);
    }

    // todo: write your code here
    public void runOpMode() {

        //this is the code that is run when the "init" button is pressed on the
        //phone. Most stuff should be here and not in :DEFINE

        //location tag
        //::INIT
        
        //motor stuff inside here
        {
            //set up motor stuff
            //there is *so much stuff*
            //but that's how it needs to be done
            //everything is repeated 4 times, once for each motor (usually)
            //the brackets are just so that I can minimize this huge block
            
            //Give motors names
            //pretty sure these are set up on the phone
            leftBack = hardwareMap.get(DcMotor.class, "leftBack");
            rightFront = hardwareMap.get(DcMotor.class, "rightFront");
            leftFront = hardwareMap.get(DcMotor.class, "leftFront");
            rightBack = hardwareMap.get(DcMotor.class, "rightBack");
            
            intake = hardwareMap.get(DcMotor.class, "intake");
            lift = hardwareMap.get(DcMotor.class, "lift");
    
            //set motors to speed mode
            leftBack.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            rightFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            leftFront.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            rightBack.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            
            intake.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
            lift.setMode(DcMotor.RunMode.RUN_USING_ENCODER);
    
            //set motors to stop at 0 power instead of coasting
            leftBack.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            rightBack.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            leftFront.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            rightFront.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            
            intake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            lift.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
            
            /*
            set two motors to go backwards
            so funny story.
            This actually works now. It used to be really stupid, but then I 
            spent some time and fixed it. It makes sense now. 
            So now {1, 1, 1, 1} makes the robot go forward. 
            */
            rightBack.setDirection(DcMotor.Direction.REVERSE);
            rightFront.setDirection(DcMotor.Direction.REVERSE);
    
            //OK the motor stuff is (finally) done
        }


        //set up the the LED on the control hub
        blinkLight = hardwareMap.get(Blinker.class, "Expansion Hub 2");

        gyroSetup();
        
        /*
        Send telemetry to phone
        side note: this is the correct format for sending telemetry
        so take a look at this if you're learning
        also the imu.getCalibrationStatus thing is just getting how
        calibrated the various sensors of the IMU are.
        Not really something to worry about.
        */
        telemetry.addData("Calibration", cimu.getCalibrationStatus().toString());
        telemetry.addData("Calibration", eimu.getCalibrationStatus().toString());
        telemetry.addData("Status", "Initialized");
        telemetry.update();


        //Waits for the "play" button (actually a triangle) to get pressed on
        //the phone
        waitForStart();
        
        while(opModeIsActive())
        {
            //getAngle();
            generalPower();
            setPower();
            telemetry.update();
            
        }
    }
    
    void getAngle()
    {
        Orientation cangles = cimu.getAngularOrientation(
            AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
        Orientation eangles = eimu.getAngularOrientation(
            AxesReference.INTRINSIC, AxesOrder.ZYX, AngleUnit.DEGREES);
            
        float firstAngle = (cangles.firstAngle + eangles.firstAngle)/2;
        float secondAngle = (cangles.secondAngle + eangles.secondAngle)/2;
        float thirdAngle = (cangles.thirdAngle + eangles.thirdAngle)/2;
        telemetry.addData("First", firstAngle);
        telemetry.addData("Second", secondAngle);
        telemetry.addData("Third", thirdAngle);
    }
    
    void generalPower()
    {
        double r = Math.hypot(gamepad1.left_stick_x, -gamepad1.left_stick_y);
        double robotAngle = Math.atan2(gamepad1.left_stick_y, gamepad1.left_stick_x);
        double rightX = gamepad1.right_stick_x;

        motor[0] = r * Math.sin(robotAngle - (Math.PI/4)) + rightX;
        motor[1] = r * Math.sin(robotAngle + (Math.PI/4)) - rightX;
        motor[2] = r * Math.sin(robotAngle - (Math.PI/4)) - rightX;
        motor[3] = r * Math.sin(robotAngle + (Math.PI/4)) + rightX;
        
        motor[4] = gamepad2.left_stick_x;
    }
    
    private void setPower()
    {
        rightBack.setPower(motor[0]);
        leftBack.setPower(motor[1]);
        leftFront.setPower(motor[2]);
        rightFront.setPower(motor[3]);
        //intake.setPower(motor[4]);
    }
    
}